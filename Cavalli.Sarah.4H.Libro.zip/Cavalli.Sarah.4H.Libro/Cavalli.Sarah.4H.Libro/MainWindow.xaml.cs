﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cavalli.Sarah._4H.Libro
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Libro> libri = new List<Libro>();

        public MainWindow()
        {
            InitializeComponent();
           
        }


        private void Go_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Libro l1 = new Libro();
                MessageBox.Show("" + l1);


                Libro l2 = new Libro("BonacciniBest;Bonaccini;2018;RomanzoFormativo;420;Sbonaccini;69");
                MessageBox.Show(l2.ToString());
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }

        }

        private void Grid_Click(object sender, RoutedEventArgs e)
        {
            Libro[] libri = new Libro[]
           {
                new Libro("IT;King;2018;Horror;420;bho;39"),
                new Libro("LOL;Manzoni;1980;Giallo;689;Feltrinelli;78"),
           };
            dgDati.ItemsSource = libri;
        }
    }

}
