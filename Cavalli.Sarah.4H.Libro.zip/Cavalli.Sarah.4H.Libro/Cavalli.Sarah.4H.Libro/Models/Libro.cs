﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cavalli.Sarah._4H.Libro
{
    public class Libro
    {

        public string Titolo { get; set; }
        public string Autore { get; set; }
        public int AnnoPubblicazione { get; set; }
        public string Genere { get; set; }
        public int NPagine { get; set; }
        public string CasaEditrice { get; set; }
        public double Prezzo { get; set; }



        //Costruttore di default 
        // costruisce un Persona (valida) dal nulla
        public Libro()
        {
            Titolo = "";
            Autore = "";
            AnnoPubblicazione = 2001;
            Genere = "";
            NPagine = 200;
            CasaEditrice = "";
            Prezzo = 15.78;

        }

        //Costruttore standard
        //costruisce un Persona con tutti i parametri
        public Libro(string Riga)
        {
            string[] colonne = Riga.Split(';');
            if (colonne.Length != 7)
            {
                throw new Exception("Errore!!!\nRiga CSV non valida!!");
            }

            Titolo = colonne[0];
            Autore = colonne[1];
            AnnoPubblicazione = Convert.ToInt32(colonne[2]);
            Genere = colonne[3];
            NPagine = Convert.ToInt32(colonne[4]);
            CasaEditrice = colonne[5];
            Prezzo = Convert.ToInt32(colonne[6]);

        }

        public override string ToString()
        {
           return $"{Titolo} {Autore} {AnnoPubblicazione}\n {Genere} ({NPagine}) \n{CasaEditrice} {Prezzo} ";
        }
       
        public string toCsv()
        {
            string csvLibro = $"{Titolo};{Autore};{AnnoPubblicazione};{Genere};{NPagine};{CasaEditrice};{Prezzo};";
            return csvLibro;
        }
    }
}
